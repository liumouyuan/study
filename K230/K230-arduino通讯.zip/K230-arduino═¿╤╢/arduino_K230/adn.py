from machine import UART
from machine import FPIOA
import time

fpioa = FPIOA()
fpioa.set_function(3,FPIOA.UART1_TXD)
fpioa.set_function(4,FPIOA.UART1_RXD)

uart = UART(UART.UART1, baudrate=115200, bits=8, timeout=1000)

def k230_uart1_send(data):
    # 发送指令
    try:
        if isinstance(data, str):
            data = data.encode('utf-8')

        uart.write(data)
        time.sleep_ms(50)  # 确保数据发送完成

        # 打印预览内容（防止非法字符导致报错）
        try:
            preview = data[:32].decode('utf-8')  # 不加 errors
        except:
            preview = str(data[:32])  # fallback
        print("发送:", preview.strip())

    except Exception as e:
        print("发送错误:", e)

def k230_uart1_receive(timeout=1000):
    # 等待 ACK（带超时）
    start = time.ticks_ms()
    received = bytearray()
    found =True

    while time.ticks_diff(time.ticks_ms(), start) < 1000:  # 超时 1000ms
        data = uart.read(32)
        if data:
            received.extend(data)
            print("收到:", data)  # 调试输出

        time.sleep_ms(10)  # 避免忙等待

    if not found:
        print("警告: 未收到数据")
    return found


while True:

    #test_data = "hello"
    #k230_uart1_send(test_data)
    #time.sleep_ms(2000)
    k230_uart1_receive(timeout=1000)
    time.sleep_ms(100)
