import cv2 as cv
import numpy as np
import threading
import serial
import time
import matplotlib
import struct
from pyzbar.pyzbar import decode


# 将列表lst中的数字元素连接为字符串，再转换为整数返回
def convert_to_num(lst):
    num_str = ''.join(str(digit) for digit in lst)
    result = int(num_str)
    return result


def send_servo(State):
    temp = [0x55, 0x55, 0x05, 0x06, State, 0x01, 0x00]
    # print(str(temp))
    ser1.write(bytearray(temp))


ser = serial.Serial("/dev/ttyUSB0", 115200)  # 与stm32进行通讯
ser1 = serial.Serial("/dev/ttyUSB2", 9600)  # 与机械臂连接通讯
ser2 = serial.Serial("/dev/ttyUSB1", 9600)  # 与串口屏进行通讯


# --------------------------------------------串口屏通讯的帧未，不要动
def setend():
    ser2.write(bytes.fromhex('ff ff ff'))


# --------------------------------------------串口屏代码，此处不要修改，虽为一坨但是百年可用
def uart_lcd(a, b, c, d, e, f):  # 读二维码，所获得的6位值传入uart_lcd函数  第277行附近
    str1 = "n0.val=" + a
    str2 = "n1.val=" + b
    str3 = "n2.val=" + c
    str4 = "n3.val=" + d
    str5 = "n4.val=" + e
    str6 = "n5.val=" + f
    ser2.write(str1.encode("GB2312"))  # a转换为GB2312格式进行串口发送#num = str(result_num).encode("utf-8")  # 转化为字符串格式进行串口发送
    setend()  # 串口屏通讯的帧尾
    time.sleep(0.2)  # 休眠0.2秒
    ser2.write(str2.encode("GB2312"))  # b转换为GB2312格式进行串口发送
    setend()  # 串口屏通讯的帧尾
    time.sleep(0.2)  # 休眠0.2秒
    ser2.write(str3.encode("GB2312"))  # c转换为GB2312格式进行串口发送
    setend()  # 串口屏通讯的帧尾
    time.sleep(0.2)  # 休眠0.2秒
    ser2.write(str4.encode("GB2312"))  # d转换为GB2312格式进行串口发送
    setend()  # 串口屏通讯的帧尾
    time.sleep(0.2)  # 休眠0.2秒
    ser2.write(str5.encode("GB2312"))  # e转换为GB2312格式进行串口发送
    setend()  # 串口屏通讯的帧尾
    time.sleep(0.2)  # 休眠0.2秒
    ser2.write(str6.encode("GB2312"))  # f转换为GB2312格式进行串口发送
    setend()  # 串口屏通讯的帧尾
    time.sleep(0.2)  # 休眠0.2秒


# ----------------------------------------stm32通讯代码
def send_stm32(ss):  # ss为
    a = 1
    stm32 = [0x7B, ss, 0x11, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x11, 0x7D]
    ser.write(bytearray(stm32))
    '''stmmove = 1
    while True:
        if ser.inWaiting() == 0:
            a = 0
            break'''


def sends_stm32(ss):  # ss为小车移动动作组编号，比如为0x55时，小车往x方向后退
    stm32 = [0x7B, ss, 0x11, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x11, 0x7D]
    ser.write(bytearray(stm32))  # 串口屏显示传入的ss转换的值


# 定义全局变量，用于多线程间的共享
# 设置一个全局锁
lock = threading.Lock()
# 一个共享的circles数组
circles = []
# 切换条件
green_lowerColor = np.array([35, 120, 80])
green_upperColor = np.array([77, 255, 255])
red_lowerColor = np.array([0, 100, 100])
red_upperColor = np.array([10, 255, 255])
blue_lowerColor = np.array([90, 70, 90])
blue_upperColor = np.array([140, 255, 255])


# 识别圆
def detect_circles(frame):  # frame = cv.circle(frame, center, 3, (0, 255, 0), -1)，frame

    global circles
    # 将帧转换为灰度图像
    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    img2 = cv.GaussianBlur(gray, (5, 5), 0)
    # img2 = cv.medianBlur(gray, 7)
    # 进行圆形检测
    # print('y')
    detected_circles = cv.HoughCircles(
        img2, cv.HOUGH_GRADIENT, dp=1, minDist=160, param1=60, param2=60, minRadius=80, maxRadius=200)
    if detected_circles is not None:
        # print('r')
        # 更新全局变量
        with lock:
            circles = detected_circles[0]


# 输出色块中心坐标
def central_coordinate(frame, color_binary):
    median = cv.medianBlur(color_binary, 9)
    # image, b, c = cv.findContours(median, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_NONE)
    b, c = cv.findContours(median, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_NONE)
    # 高版本的cv.findContours去掉image返回值
    rres = cv.drawContours(frame, b, -1, (0, 0, 255), 3)
    max_contour = max(b, key=cv.contourArea, default=None)
    # default提供一个关键字参数，防止空列表错误
    if max_contour is not None:
        (x, y), radius = cv.minEnclosingCircle(max_contour)
        center = (int(x), int(y))
        frame = cv.circle(frame, center, 3, (0, 255, 0), -1)
        print(center)


# 输出圆环的中心坐标
def draw_circles(frame):
    # 用with自动关锁
    global flag
    global wait
    global time_start_1
    global switch
    global ab
    with lock:
        for ip in circles:
            # print('l')
            t = 0
            t += 1
            if t == 3:
                # break_flag = True
                break
            a = int(i[0]) - int(i[2])
            if a <= 0:
                a = 0
            b = int(i[0]) + int(i[2])
            if b >= 640:
                b = 640
            c = int(i[1]) - int(i[2])
            if c <= 0:
                c = 0
            d = int(i[1]) + int(i[2])
            if d >= 480:
                d = 480
            img3 = frame[c:d, a:b]
            # 识别部分
            HSV = cv.cvtColor(img3, cv.COLOR_BGR2HSV)  # 将帧转换为HSV度图像
            binary = cv.inRange(HSV, green_lowerColor, green_upperColor)
            area = cv.countNonZero(binary)
            if binary.any() and area > 300:
                cv.circle(frame, (int(i[0]), int(i[1])), int(i[2]), (0, 255, 255), 3)
                print(i[0], i[1])
                print(flag)
                if wait == 1:
                    time_start_1 = int(time.time())
                    wait = 2
                if time_start_1 != int(time.time()) and flag == 0:
                    time_start_1 = int(time.time())
                    flag = 1
                elif time_start_1 != int(time.time()) and flag == 3:
                    time_start_1 = int(time.time())
                    flag = 2
                if i[0] > 350 and flag == 1:

                    flag = 0
                    print('kk')
                elif i[0] < 340 and flag == 1:

                    flag = 0
                elif i[0] < 350 and i[0] > 340 and flag != 2 and flag != 3:
                    flag = 2

                    # switch=5
                    print('oo')
                if i[1] > 290 and flag == 2:

                    flag = 3
                elif i[1] < 280 and flag == 2:

                    flag = 3
                elif i[1] < 290 and i[1] > 280 and flag != 1 and flag != 0 and ab == 0:

                    flag = 1
                    switch = 5
                elif i[1] < 290 and i[1] > 280 and flag != 1 and flag != 0 and ab != 0:
                    flag = 1
                    switch = 0
                    ab = 0


switch = 0  # 运行进度
i = 0  # 抓取颜色顺序
ii = 0
delay = 1  # 第一次不抓取
flag = 0  # 此处使其先调x再调y
wait = 1  # 延迟
j = 0
fox = 0  # 第一轮放置物料（暂存区）
foxx = 0  # 第一轮放下物料（粗加工区）
foxxx = 0  # 第二轮不同高度时放（粗加工区）
list = []
time_start_1 = 0
switch2 = 0
ires = 1
iress = 1
fres = 1
fress = 1  # 未知具体
cok = 1  # 未知具体
ab = 0  # 未知具体
x = 0
xx = 0
xxx = 0
sw = 0
sw2 = 0
sw3 = 0
ter = 0
it = 0


# 这里开始改
def display_frame():
    # 初始化摄像头
    global it
    global ter
    global ab
    global cok
    global switch
    global delay
    global i
    global xxx
    global x
    global xx
    global ii  # i是拿
    global flag
    global list
    global sw
    global sw2
    global fox  # fox是放
    global foxx
    global foxx
    global ires
    global iress
    global fres
    global fress
    cap = cv.VideoCapture(0)
    cap.set(6, cv.VideoWriter.fourcc('M', 'J', 'P', 'G'))
    t = 1
    while True:
        # print('1')
        # print(switch)
        # 读取视频流的帧
        # ser2 = serial.Serial("/dev/ttyUSB1", 9600)
        ret, frame = cap.read()
        cv.imshow('frame', frame)
        if cv.waitKey(10) & 0xFF == ord('q'):
            break
        '''t += 1
        # 每隔3帧处理一次
        if t % 3 != 0:
            ret = cap.grab()
            #print('1')
            continue'''
        # 在主线程中启动其它线程
        if sw == 0:
            send_servo(0x01)
            sw = 1

        count = ser.inWaiting()
        if count != 0:
            sint = ser.read()  # stm32返回的值
            print(sint)
            if sint == b'1':  # 开始识别二维码
                switch = 1  # 进行动作组
                send_servo(0x02)
            if sint == b'3':  # 开始第一次识别
                if i == 3:
                    time.sleep(5)
                    send_servo(0x0c)  # go away things
                    time.sleep(1.5)
                    for ki in range(6):
                        send_stm32(0x07)  # 延时并且到粗加工返5
                    switch = 0
                else:
                    print("ready_shibie")
                    switch = 3  # yuanbenwei3
                    send_servo(0x04)
            if sint == b'4':  # 正式识别
                print('shibie')
                time.sleep(0.7)
                switch = 4
            if sint == b'5':
                switch = 5
                print('fasong55')
        # -----------------------------------------识别二维码
        if ret and switch == 1:

            decoded_objects = decode(frame)

            # 遍历识别到的二维码
            for obj in decoded_objects:
                # 提取二维码数据和位置

                data = obj.data.decode('utf-8')
                points = obj.polygon

                # 在图像上绘制二维码边框
                if len(points) > 4:
                    hull = cv.convexHull(np.array([point for point in points], dtype=np.float32))
                    cv.polylines(frame, [hull], True, (0, 255, 0), 2)
                # 在图像上显示二维码数据
                cv.putText(frame, data, (50, 50), cv.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                for b in str(data):  # 将二维码变成str格式以此储存到列表中
                    if b != '+':  # 将+号不储存到列表中
                        line = b  # 将数字储存在line中
                        list.append(line)  # 这里储存列表中，例如二维码为123+321即有1，2，3，3，2，1
                        send_servo(0x03)
                        switch = 2
        if switch == 2:
            a = [list[0], list[1], list[2], list[3], list[4], list[5]]  # 将列表中的内容重新储存到a中，测试使用
            print(a[0])
            print(a[1])
            print(a[2])
            print(a[3])
            print(a[4])
            print(a[5])
            uart_lcd(a[0], a[1], a[2], a[3], a[4], a[5])  # 读二维码，所获得的6位值传入uart_lcd函数
            time.sleep(1)
            for jj in range(6):
                send_stm32(0x02)  # 开到原料区，延时返3
            switch = 0

        # ------------------------------------------------------------------------------------------

        # ----------------------------------------识别颜色部分

        if switch == 3:
            # print("888888")

            # time.sleep(2)
            if a[x] == '1':

                HSV = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
                red_binary = cv.inRange(HSV, red_lowerColor, red_upperColor)
                area = cv.countNonZero(red_binary)

                if red_binary.any() and area > 1000:
                    x = x + 1
                    print("1111")

                    # send_servo(0x04)
                    for jj in range(10):
                        send_stm32(0x44)  # 表示延时4秒后回传4
                    switch = 0
            if a[x] == '2':
                HSV = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
                green_binary = cv.inRange(HSV, green_lowerColor, green_upperColor)
                area = cv.countNonZero(green_binary)
                if green_binary.any() and area > 7000:
                    x = x + 1
                    print('2222')

                    # send_servo(0x04)
                    for jj in range(10):
                        send_stm32(0x44)  # 表示延时4秒后回4
                    switch = 0
            if a[x] == '3':
                HSV = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
                blue_binary = cv.inRange(HSV, blue_lowerColor, blue_upperColor)
                area = cv.countNonZero(blue_binary)
                if blue_binary.any() and area > 7000:
                    x = x + 1
                    print('3333')

                    # send_servo(0x04)
                    for jj in range(10):
                        send_stm32(0x44)  # 表示延时4秒后回4
                    switch = 0
        # ---------------------------------------------------正式识别
        if switch == 4:
            print('go_switch==4')
            # print('66666')
            if a[i] == '1':
                # print("11")
                HSV = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
                red_binary = cv.inRange(HSV, red_lowerColor, red_upperColor)
                area = cv.countNonZero(red_binary)

                if red_binary.any() and area > 600:

                    i = i + 1
                    print('red_1')
                    send_servo(0x05)  # 抓红色
                    print('red_2')
                    for jj in range(10):
                        send_stm32(0x43)  # 延时返3
                    print('red_3')
                    switch = 0
            elif a[i] == '2':
                # send_servo(0x04)
                # print("22")
                HSV = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
                green_binary = cv.inRange(HSV, green_lowerColor, green_upperColor)
                area = cv.countNonZero(green_binary)
                if green_binary.any() and area > 600:
                    i = i + 1
                    print("green_1")
                    send_servo(0x06)  # 抓绿色
                    print("green_2")
                    for jj in range(10):
                        send_stm32(0x43)  # 延时返3
                    print('green_3')
                    switch = 0
            elif a[i] == '3':
                # print('33')
                HSV = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
                blue_binary = cv.inRange(HSV, blue_lowerColor, blue_upperColor)
                area = cv.countNonZero(blue_binary)
                if blue_binary.any() and area > 600:
                    i = i + 1
                    print('blue_1')
                    send_servo(0x0b)  # 抓蓝色
                    print('blue_2')
                    for jj in range(10):
                        send_stm32(0x43)  # 延时返3

                    print('blue_3')
                    switch = 0

        # -------------------------------------------------------------------------------------------

        # -----------------------------------------放置粗加工区
        if switch == 5:
            if a[fox] == '1':

                time.sleep(2)
                for ji in range(8):
                    send_stm32(0x12)  # 绿到红
                time.sleep(2)
                send_servo(0x0e)
                time.sleep(8)
                fox = fox + 1
                for ji in range(8):
                    send_stm32(0x10)  # 红回绿 返5
                switch = 5
                if fox == 3:
                    switch = 44
        if switch == 5:
            if a[fox] == '2':
                time.sleep(2)
                send_servo(0x0f)
                time.sleep(8)
                fox = fox + 1
                switch = 5
                if fox == 3:
                    switch = 44
        if switch == 5:
            if a[fox] == '3':
                time.sleep(2)
                for ji in range(8):
                    send_stm32(0x10)  # 绿到蓝
                time.sleep(2)
                send_servo(0x10)
                time.sleep(8)
                fox = fox + 1
                for ji in range(8):
                    send_stm32(0x12)  # 蓝回绿
                switch = 5
                if fox == 3:
                    switch = 44
        # ------------------------------------drop out car
        if switch == 44:
            time.sleep(2)
            print('good1')
            for ju in range(8):
                send_stm32(0x20)
                print('good2')
            time.sleep(3)
            switch = 6

        if switch == 6:
            if a[foxx] == '1':
                print('q')
                time.sleep(2)
                for ju in range(8):
                    send_stm32(0x12)  # 绿到红
                time.sleep(2)
                print('red1')
                send_servo(0x11)  # 抓红色
                print('red2')
                time.sleep(8)
                for ju in range(8):
                    send_stm32(0x10)  # 红回绿
                    print('red3')
                foxx = foxx + 1
                switch = 6
                if foxx == 3:
                    ter = 1
                    switch = 8
        if switch == 6:
            if a[foxx] == '2':
                print('w')
                time.sleep(2)
                send_servo(0x12)  # 抓绿色
                print('green1')
                time.sleep(8)
                foxx = foxx + 1
                switch = 6
                if foxx == 3:
                    ter = 1
                    switch = 8
        if switch == 6:
            if a[foxx] == '3':
                print('e')
                time.sleep(2)
                for ju in range(8):
                    send_stm32(0x10)  # 绿到蓝
                time.sleep(2)
                print('blue1')
                send_servo(0x13)  # 抓蓝
                time.sleep(8)
                for ju in range(8):
                    send_stm32(0x12)  # 蓝回绿
                foxx = foxx + 1
                switch = 6
                if foxx == 3:
                    ter = 1
                    switch = 8
        # -----------------------------------------------------------------------------------暂存区
        if switch == 8:
            time.sleep(8)
            for ii in range(6):
                send_stm32(0x77)
            time.sleep(8)
            switch=0

                    # cv.imshow('frame', frame)
        # 按下 'q' 键退出循环
        # if cv.waitKey(10) & 0xFF == ord('q'):
        # break


# 启动显示帧的线程
threading.Thread(target=display_frame).start()
